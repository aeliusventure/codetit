
$.map.setCamera ({
	latitude:51.43580627441406,
	longitude:-0.14256912469863892,
	zoom:15,
	bearing:0,
	viewingAngle:0
});

$.index.open();
